// Server-triggered WhatsApp messages via Meta's WhatsApp Cloud API.
//
// This requires a Meta WhatsApp Business API setup: a verified Meta Business
// account, a registered WhatsApp business phone number, and at least one
// APPROVED message template (Meta reviews and approves templates before
// you can send them to numbers that haven't messaged you first). That
// approval process happens on Meta's side — no code can substitute for it.
//
// Until WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID are set in .env, this
// module safely no-ops and logs instead of sending, so the rest of the app
// (bookings, email) keeps working normally.
//
// The site's "Message us on WhatsApp" buttons do NOT depend on any of this —
// those are plain wa.me links and work with zero setup.

async function sendWhatsAppConfirmation(booking) {
  const { WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID } = process.env;

  if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID) {
    console.warn(
      '[whatsapp] WHATSAPP_TOKEN / WHATSAPP_PHONE_NUMBER_ID not set — skipping automated WhatsApp message. ' +
      `(Would have confirmed ${booking.pref_date} ${booking.pref_slot} to ${booking.phone}.)`
    );
    return { sent: false, reason: 'not_configured' };
  }

  // Normalise to E.164 digits only, assuming Indian numbers if no country code given.
  let to = String(booking.phone).replace(/[^\d]/g, '');
  if (to.length === 10) to = '91' + to;

  const url = `https://graph.facebook.com/v20.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`;

  // NOTE: replace 'booking_confirmation' with the exact name of a template
  // you have created and had approved in Meta Business Manager, with
  // matching {{1}} / {{2}} placeholders.
  const body = {
    messaging_product: 'whatsapp',
    to,
    type: 'template',
    template: {
      name: 'booking_confirmation',
      language: { code: 'en' },
      components: [
        {
          type: 'body',
          parameters: [
            { type: 'text', text: booking.pref_date },
            { type: 'text', text: booking.pref_slot }
          ]
        }
      ]
    }
  };

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${WHATSAPP_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok) {
      console.error('[whatsapp] Send failed:', data);
      return { sent: false, reason: 'api_error', error: data };
    }
    return { sent: true, data };
  } catch (err) {
    console.error('[whatsapp] Request failed:', err.message);
    return { sent: false, reason: 'network_error', error: err.message };
  }
}

module.exports = { sendWhatsAppConfirmation };
