const db = require('./db');

// Fallback values used the first time the app runs, before the admin has
// edited anything in the dashboard. Editing these later requires no code
// changes — use the Site Settings panel in /admin/dashboard instead.
const DEFAULTS = {
  facebook_url: 'https://www.facebook.com/search/top?q=Ankit%20Srivas%20Alex%20Celebrity%20Makeup%20Artist',
  instagram_url: 'https://instagram.com/26alexmakeoverjhansi',
  whatsapp_number: process.env.BUSINESS_WHATSAPP_NUMBER || '919120807102',
  contact_email: 'ankitsriveas080@gmail.com',
  business_phone_display: process.env.BUSINESS_PHONE_DISPLAY || '+91 91208 07102',
  address: 'Khati Baba Road, Azad Ganj, near Aarya Kanya Chauraha, Sipri Bazar, Jhansi, Uttar Pradesh 284002',
  announcement: ''
};

const EDITABLE_KEYS = Object.keys(DEFAULTS);

function getAllSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const fromDb = Object.fromEntries(rows.map(r => [r.key, r.value]));
  return { ...DEFAULTS, ...fromDb };
}

function setSettings(partial) {
  const upsert = db.prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `);
  const tx = db.transaction(obj => {
    for (const key of Object.keys(obj)) {
      if (!EDITABLE_KEYS.includes(key)) continue; // ignore unknown fields
      upsert.run(key, String(obj[key] ?? ''));
    }
  });
  tx(partial);
  return getAllSettings();
}

module.exports = { getAllSettings, setSettings, EDITABLE_KEYS, DEFAULTS };
