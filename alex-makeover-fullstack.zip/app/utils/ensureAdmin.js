const bcrypt = require('bcryptjs');
const db = require('./db');

/**
 * Creates the admin account from ADMIN_EMAIL/ADMIN_PASSWORD if none exists
 * yet, or updates the password if that email already exists but the env
 * var password has changed. Safe to call every time the app boots — most
 * runs it's a no-op (email already matches, password already matches).
 *
 * This means on a host like Render, setting ADMIN_EMAIL/ADMIN_PASSWORD in
 * the dashboard and deploying is enough — no shell/console step required.
 */
async function ensureAdmin({ silent = false } = {}) {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  const log = silent ? () => {} : (...args) => console.log(...args);

  if (!email || !password) {
    if (!silent) console.warn('[ensureAdmin] ADMIN_EMAIL / ADMIN_PASSWORD not set — skipping admin setup.');
    return { ok: false, reason: 'missing_env' };
  }
  if (password.length < 8) {
    console.warn('[ensureAdmin] ADMIN_PASSWORD is shorter than 8 characters — allowed, but easy to guess. Consider a longer one.');
  }

  const existing = db.prepare('SELECT id, password_hash FROM admins WHERE email = ?').get(email);

  if (!existing) {
    const passwordHash = await bcrypt.hash(password, 12);
    db.prepare('INSERT INTO admins (email, password_hash, created_at) VALUES (?, ?, ?)')
      .run(email, passwordHash, new Date().toISOString());
    log(`[ensureAdmin] Created admin account: ${email}`);
    return { ok: true, action: 'created' };
  }

  // Only rehash/update if the current env password no longer matches what's
  // stored, so we're not doing a bcrypt compare + hash on every single boot
  // for no reason.
  const matches = await bcrypt.compare(password, existing.password_hash);
  if (!matches) {
    const passwordHash = await bcrypt.hash(password, 12);
    db.prepare('UPDATE admins SET password_hash = ? WHERE email = ?').run(passwordHash, email);
    log(`[ensureAdmin] Password changed in env — updated admin account: ${email}`);
    return { ok: true, action: 'updated' };
  }

  return { ok: true, action: 'unchanged' };
}

module.exports = { ensureAdmin };
