const nodemailer = require('nodemailer');

let transporter = null;
let configured = false;

function getTransporter() {
  if (transporter) return transporter;

  const { EMAIL_USER, EMAIL_PASS } = process.env;
  if (!EMAIL_USER || !EMAIL_PASS) {
    console.warn(
      '[mailer] EMAIL_USER / EMAIL_PASS not set in .env — emails will be logged to the console instead of sent.'
    );
    configured = false;
    return null;
  }

  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: EMAIL_USER, pass: EMAIL_PASS }
  });
  configured = true;
  return transporter;
}

async function sendMail({ to, subject, text, html }) {
  const t = getTransporter();
  const from = process.env.EMAIL_USER || 'no-reply@alexmakeover.local';

  if (!t) {
    // Not configured — log instead of throwing, so the rest of the app
    // (saving the booking, showing a response to the user) still works.
    console.log('--- [mailer] EMAIL NOT SENT (not configured) ---');
    console.log('To:', to);
    console.log('Subject:', subject);
    console.log(text);
    console.log('-------------------------------------------------');
    return { sent: false, reason: 'not_configured' };
  }

  try {
    await t.sendMail({ from, to, subject, text, html });
    return { sent: true };
  } catch (err) {
    console.error('[mailer] Failed to send email:', err.message);
    return { sent: false, reason: 'send_error', error: err.message };
  }
}

function notifyAdminsOfNewBooking(booking) {
  const notifyList = (process.env.ADMIN_NOTIFY_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (notifyList.length === 0) {
    console.warn('[mailer] ADMIN_NOTIFY_EMAILS is empty — no admin notification sent.');
    return Promise.resolve({ sent: false, reason: 'no_recipients' });
  }
  const subject = `New booking request — ${booking.name} (${booking.service})`;
  const text =
    `New booking request received on the Alex Makeover website.\n\n` +
    `Name: ${booking.name}\n` +
    `Phone/WhatsApp: ${booking.phone}\n` +
    `Email: ${booking.email}\n` +
    `Service: ${booking.service}\n` +
    `Preferred date: ${booking.pref_date}\n` +
    `Preferred slot: ${booking.pref_slot}\n` +
    `Notes: ${booking.notes || '(none)'}\n\n` +
    `Log in to the admin dashboard to confirm this booking.`;
  return sendMail({ to: notifyList.join(','), subject, text });
}

function sendClientConfirmation(booking) {
  const subject = 'Your appointment at Alex Makeover, Jhansi is confirmed';
  const text =
    `Thank you for booking with Alex Makeover, Jhansi! Your appointment has been ` +
    `confirmed for ${booking.pref_date}, ${booking.pref_slot}. We look forward to serving you.\n\n` +
    `Service: ${booking.service}\n` +
    `Address: Khati Baba Road, Azad Ganj, near Aarya Kanya Chauraha, Sipri Bazar, Jhansi, UP 284002\n` +
    `Questions? Call or WhatsApp ${process.env.BUSINESS_PHONE_DISPLAY || ''}.`;
  return sendMail({ to: booking.email, subject, text });
}

module.exports = { sendMail, notifyAdminsOfNewBooking, sendClientConfirmation };
