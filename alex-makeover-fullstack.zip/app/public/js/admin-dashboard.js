document.addEventListener('DOMContentLoaded', () => {
  const listEl = document.getElementById('dashList');
  const logoutBtn = document.getElementById('logoutBtn');
  if (!listEl) return;

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  async function loadBookings() {
    listEl.innerHTML = '<div class="empty">Loading booking requests…</div>';
    try {
      const res = await fetch('/api/bookings');
      if (res.status === 401) { window.location.href = '/admin/login'; return; }
      const data = await res.json();
      if (!data.ok) throw new Error('Could not load bookings.');
      if (data.bookings.length === 0) {
        listEl.innerHTML = '<div class="empty">No booking requests yet.</div>';
        return;
      }
      listEl.innerHTML = '';
      data.bookings.forEach(b => {
        const confirmed = b.status === 'confirmed';
        const card = document.createElement('div');
        card.className = 'booking-card';
        card.innerHTML = `
          <div class="meta">
            <b>${escapeHtml(b.name)}</b> — ${escapeHtml(b.service)}<br>
            ${escapeHtml(b.phone)} · ${escapeHtml(b.email)}<br>
            Requested: ${escapeHtml(b.pref_date)}, ${escapeHtml(b.pref_slot)}
            ${b.notes ? '<br>Notes: ' + escapeHtml(b.notes) : ''}
          </div>
          <div style="display:flex; flex-direction:column; gap:10px; align-items:flex-end;">
            <span class="status-pill ${confirmed ? 'confirmed' : ''}">${confirmed ? 'Confirmed' : 'Pending'}</span>
            <button class="btn-confirm" data-id="${b.id}" ${confirmed ? 'disabled' : ''}>
              ${confirmed ? 'Confirmation sent' : 'Confirm booking'}
            </button>
            <button class="btn-delete" data-id="${b.id}">Delete</button>
          </div>`;
        listEl.appendChild(card);
      });

      listEl.querySelectorAll('.btn-confirm').forEach(btn => {
        btn.addEventListener('click', async () => {
          btn.disabled = true;
          btn.textContent = 'Confirming…';
          try {
            const res = await fetch(`/api/bookings/${btn.dataset.id}/confirm`, { method: 'POST' });
            const data = await res.json();
            if (!data.ok) throw new Error('Confirm failed.');
            const emailNote = data.emailResult.sent
              ? 'Confirmation email sent.'
              : 'Email NOT sent (EMAIL_USER/EMAIL_PASS not configured yet) — check the server console for the message that would have gone out.';
            const waNote = data.whatsappResult.sent
              ? 'WhatsApp confirmation sent.'
              : 'WhatsApp message not sent (WhatsApp Cloud API not configured yet).';
            alert(emailNote + '\n' + waNote);
            loadBookings();
          } catch (err) {
            btn.disabled = false;
            btn.textContent = 'Confirm booking';
            alert('Could not confirm this booking. Please try again.');
          }
        });
      });

      listEl.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('Delete this booking request? This cannot be undone.')) return;
          await fetch(`/api/bookings/${btn.dataset.id}`, { method: 'DELETE' });
          loadBookings();
        });
      });
    } catch (err) {
      listEl.innerHTML = '<div class="empty">Could not load booking requests.</div>';
    }
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await fetch('/api/auth/logout', { method: 'POST' });
      window.location.href = '/admin/login';
    });
  }

  loadBookings();
});
