document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  if (!form) return;
  const statusEl = document.getElementById('loginStatus');
  const submitBtn = document.getElementById('loginBtn');

  form.addEventListener('submit', async e => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Signing in…';
    statusEl.classList.remove('show', 'error');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email.value.trim(), password: form.password.value })
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Login failed.');
      window.location.href = '/admin/dashboard';
    } catch (err) {
      statusEl.textContent = err.message;
      statusEl.classList.add('show', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Sign in';
    }
  });
});
