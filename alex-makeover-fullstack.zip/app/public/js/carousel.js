/**
 * Minimal, dependency-free carousel.
 * Usage: <div class="carousel" data-autoplay="5000">
 *          <div class="carousel-track">
 *            <div class="carousel-slide">...</div>
 *            <div class="carousel-slide">...</div>
 *          </div>
 *          <button class="carousel-prev">&#8249;</button>
 *          <button class="carousel-next">&#8250;</button>
 *          <div class="carousel-dots"></div>
 *        </div>
 * Call initCarousels() after the DOM is ready (main.js does this).
 */
function initCarousels() {
  document.querySelectorAll('.carousel').forEach(root => {
    if (root.dataset.carouselInit) return; // avoid double-init
    root.dataset.carouselInit = '1';

    const track = root.querySelector('.carousel-track');
    const slides = Array.from(root.querySelectorAll('.carousel-slide'));
    const dotsWrap = root.querySelector('.carousel-dots');
    const prevBtn = root.querySelector('.carousel-prev');
    const nextBtn = root.querySelector('.carousel-next');
    if (!track || slides.length === 0) return;

    let index = 0;
    let timer = null;
    const autoplayMs = Number(root.dataset.autoplay || 0);

    if (dotsWrap) {
      dotsWrap.innerHTML = '';
      slides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
        dot.addEventListener('click', () => goTo(i));
        dotsWrap.appendChild(dot);
      });
    }

    function render() {
      track.style.transform = `translateX(-${index * 100}%)`;
      if (dotsWrap) {
        Array.from(dotsWrap.children).forEach((dot, i) => {
          dot.classList.toggle('active', i === index);
        });
      }
      root.dispatchEvent(new CustomEvent('carousel:change', { detail: { index } }));
    }

    function goTo(i) {
      index = (i + slides.length) % slides.length;
      render();
      restartAutoplay();
    }

    // Expose a small API so other scripts (e.g. a thumbnail grid) can
    // drive this same carousel instead of manipulating the track directly
    // — that's what caused slides to fall out of sync before.
    root.carouselApi = { goTo, next, prev, getIndex: () => index };

    function next() { goTo(index + 1); }
    function prev() { goTo(index - 1); }

    function restartAutoplay() {
      if (!autoplayMs) return;
      if (timer) clearInterval(timer);
      timer = setInterval(next, autoplayMs);
    }

    if (nextBtn) nextBtn.addEventListener('click', next);
    if (prevBtn) prevBtn.addEventListener('click', prev);

    // Swipe support for touch devices.
    let touchStartX = null;
    track.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', e => {
      if (touchStartX === null) return;
      const dx = e.changedTouches[0].clientX - touchStartX;
      if (Math.abs(dx) > 40) { dx < 0 ? next() : prev(); }
      touchStartX = null;
    }, { passive: true });

    // Pause autoplay while the user's mouse is over the carousel.
    root.addEventListener('mouseenter', () => { if (timer) clearInterval(timer); });
    root.addEventListener('mouseleave', restartAutoplay);

    render();
    restartAutoplay();
  });
}

window.initCarousels = initCarousels;
