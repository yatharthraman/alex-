document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('settingsForm');
  if (!form) return;
  const statusEl = document.getElementById('settingsStatus');
  const saveBtn = document.getElementById('settingsSaveBtn');

  function showStatus(msg, isError) {
    statusEl.textContent = msg;
    statusEl.classList.remove('error');
    if (isError) statusEl.classList.add('error');
    statusEl.classList.add('show');
  }

  async function loadSettings() {
    try {
      const res = await fetch('/api/settings');
      if (res.status === 401) { window.location.href = '/admin/login'; return; }
      const data = await res.json();
      if (!data.ok) return;
      const s = data.settings;
      form.facebook_url.value = s.facebook_url || '';
      form.instagram_url.value = s.instagram_url || '';
      form.whatsapp_number.value = s.whatsapp_number || '';
      form.business_phone_display.value = s.business_phone_display || '';
      form.contact_email.value = s.contact_email || '';
      form.address.value = s.address || '';
      form.announcement.value = s.announcement || '';
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving…';
    const payload = {
      facebook_url: form.facebook_url.value.trim(),
      instagram_url: form.instagram_url.value.trim(),
      whatsapp_number: form.whatsapp_number.value.trim(),
      business_phone_display: form.business_phone_display.value.trim(),
      contact_email: form.contact_email.value.trim(),
      address: form.address.value.trim(),
      announcement: form.announcement.value.trim()
    };
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Could not save settings.');
      showStatus('Settings saved — live across the site now.', false);
    } catch (err) {
      showStatus(err.message, true);
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save settings';
    }
  });

  loadSettings();
});
