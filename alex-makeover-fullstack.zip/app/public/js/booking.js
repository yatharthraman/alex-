document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('bookingForm');
  if (!form) return;
  const statusEl = document.getElementById('formStatus');
  const submitBtn = document.getElementById('submitBtn');

  function showStatus(msg, isError) {
    statusEl.textContent = msg;
    statusEl.classList.remove('error');
    if (isError) statusEl.classList.add('error');
    statusEl.classList.add('show');
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending…';

    const payload = {
      name: form.fname.value.trim(),
      phone: form.fphone.value.trim(),
      email: form.femail.value.trim(),
      service: form.fservice.value,
      date: form.fdate.value,
      slot: form.ftime.value,
      notes: form.fnotes.value.trim()
    };

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Something went wrong.');
      form.reset();
      showStatus(data.message || 'Request received — we will confirm shortly.', false);
    } catch (err) {
      showStatus(err.message || 'Could not send your request. Please call or WhatsApp us directly.', true);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Send booking request';
    }
  });
});
