document.addEventListener('DOMContentLoaded', () => {
  const burger = document.getElementById('burgerBtn');
  const mobileLinks = document.getElementById('mobileLinks');
  if (burger && mobileLinks) {
    burger.addEventListener('click', () => {
      const isOpen = mobileLinks.classList.toggle('open');
      burger.setAttribute('aria-expanded', String(isOpen));
    });
    mobileLinks.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        mobileLinks.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
      });
    });
  }

  if (window.initCarousels) window.initCarousels();
});
