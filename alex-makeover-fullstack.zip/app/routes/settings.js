const express = require('express');
const { requireAuthApi } = require('../middleware/requireAuth');
const { getAllSettings, setSettings } = require('../utils/siteSettings');

const router = express.Router();

router.get('/', requireAuthApi, (req, res) => {
  res.json({ ok: true, settings: getAllSettings() });
});

router.post('/', requireAuthApi, (req, res) => {
  const body = req.body || {};

  // Light validation — keep bad input from silently breaking links.
  if (body.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.contact_email)) {
    return res.status(400).json({ ok: false, error: 'Contact email looks invalid.' });
  }
  if (body.whatsapp_number && !/^\d{10,15}$/.test(body.whatsapp_number.replace(/[^\d]/g, ''))) {
    return res.status(400).json({ ok: false, error: 'WhatsApp number should be digits only, with country code (e.g. 919120807102).' });
  }
  for (const field of ['facebook_url', 'instagram_url']) {
    if (body[field] && !/^https?:\/\//i.test(body[field])) {
      return res.status(400).json({ ok: false, error: `${field.replace('_', ' ')} should start with http:// or https://` });
    }
  }

  const patch = {};
  if (body.facebook_url !== undefined) patch.facebook_url = body.facebook_url;
  if (body.instagram_url !== undefined) patch.instagram_url = body.instagram_url;
  if (body.whatsapp_number !== undefined) patch.whatsapp_number = body.whatsapp_number.replace(/[^\d]/g, '');
  if (body.contact_email !== undefined) patch.contact_email = body.contact_email;
  if (body.business_phone_display !== undefined) patch.business_phone_display = body.business_phone_display;
  if (body.address !== undefined) patch.address = body.address;
  if (body.announcement !== undefined) patch.announcement = body.announcement;

  const updated = setSettings(patch);

  res.json({ ok: true, settings: updated });
});

module.exports = router;
