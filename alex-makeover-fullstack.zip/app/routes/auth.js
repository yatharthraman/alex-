const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../utils/db');

const router = express.Router();

// Simple in-memory rate limiting per IP to slow down brute-force login
// attempts. Resets on server restart — fine for a small single-instance
// deployment; swap for a Redis-backed limiter if you scale to multiple
// instances.
const attempts = new Map(); // ip -> { count, firstAttemptAt }
const MAX_ATTEMPTS = 8;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes

function isRateLimited(ip) {
  const rec = attempts.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.firstAttemptAt > WINDOW_MS) {
    attempts.delete(ip);
    return false;
  }
  return rec.count >= MAX_ATTEMPTS;
}

function recordFailure(ip) {
  const rec = attempts.get(ip);
  if (!rec) {
    attempts.set(ip, { count: 1, firstAttemptAt: Date.now() });
  } else {
    rec.count += 1;
  }
}

function clearFailures(ip) {
  attempts.delete(ip);
}

router.post('/login', async (req, res) => {
  const ip = req.ip;
  if (isRateLimited(ip)) {
    return res.status(429).json({ ok: false, error: 'Too many attempts. Try again later.' });
  }

  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (!email || !password) {
    return res.status(400).json({ ok: false, error: 'Email and password are required.' });
  }

  const admin = db.prepare('SELECT * FROM admins WHERE email = ?').get(email);
  if (!admin) {
    recordFailure(ip);
    return res.status(401).json({ ok: false, error: 'Invalid email or password.' });
  }

  const match = await bcrypt.compare(password, admin.password_hash);
  if (!match) {
    recordFailure(ip);
    return res.status(401).json({ ok: false, error: 'Invalid email or password.' });
  }

  clearFailures(ip);
  req.session.adminId = admin.id;
  req.session.adminEmail = admin.email;
  res.json({ ok: true });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ ok: true });
  });
});

router.get('/me', (req, res) => {
  if (req.session && req.session.adminId) {
    return res.json({ ok: true, email: req.session.adminEmail });
  }
  res.status(401).json({ ok: false });
});

module.exports = router;
