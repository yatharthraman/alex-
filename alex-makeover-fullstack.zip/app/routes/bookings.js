const express = require('express');
const db = require('../utils/db');
const { requireAuthApi } = require('../middleware/requireAuth');
const { notifyAdminsOfNewBooking, sendClientConfirmation } = require('../utils/mailer');
const { sendWhatsAppConfirmation } = require('../utils/whatsapp');

const router = express.Router();

const VALID_SERVICES = ['Bridal Makeup', 'Party Makeup', 'Hair Treatment', 'Salon Service', 'Academy Course'];

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// PUBLIC: submit a booking request from the site's booking form.
router.post('/', async (req, res) => {
  const { name, phone, email, service, date, slot, notes } = req.body;

  if (!name || !phone || !email || !service || !date || !slot) {
    return res.status(400).json({ ok: false, error: 'Please fill in all required fields.' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ ok: false, error: 'Please enter a valid email address.' });
  }
  if (!VALID_SERVICES.includes(service)) {
    return res.status(400).json({ ok: false, error: 'Please choose a valid service.' });
  }

  const submittedAt = new Date().toISOString();
  const result = db.prepare(`
    INSERT INTO bookings (name, phone, email, service, pref_date, pref_slot, notes, status, submitted_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
  `).run(String(name).trim(), String(phone).trim(), String(email).trim(), service, date, slot, notes ? String(notes).trim() : '', submittedAt);

  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(result.lastInsertRowid);

  // Fire-and-forget: don't make the client wait on email delivery.
  notifyAdminsOfNewBooking(booking).catch(err => console.error('Admin notify failed:', err));

  res.json({ ok: true, message: 'Booking request received. We will confirm shortly by WhatsApp or email.' });
});

// PROTECTED: list all bookings for the admin dashboard.
router.get('/', requireAuthApi, (req, res) => {
  const rows = db.prepare('SELECT * FROM bookings ORDER BY submitted_at DESC').all();
  res.json({ ok: true, bookings: rows });
});

// PROTECTED: confirm a booking — updates status, emails the client, and
// attempts a WhatsApp confirmation if the Cloud API is configured.
router.post('/:id/confirm', requireAuthApi, async (req, res) => {
  const id = Number(req.params.id);
  const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
  if (!booking) return res.status(404).json({ ok: false, error: 'Booking not found.' });

  const confirmedAt = new Date().toISOString();
  db.prepare('UPDATE bookings SET status = ?, confirmed_at = ? WHERE id = ?').run('confirmed', confirmedAt, id);
  const updated = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);

  const emailResult = await sendClientConfirmation(updated);
  const whatsappResult = await sendWhatsAppConfirmation(updated);

  res.json({ ok: true, booking: updated, emailResult, whatsappResult });
});

// PROTECTED: delete a booking (e.g. spam / duplicate entries).
router.delete('/:id', requireAuthApi, (req, res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM bookings WHERE id = ?').run(id);
  res.json({ ok: true });
});

module.exports = router;
