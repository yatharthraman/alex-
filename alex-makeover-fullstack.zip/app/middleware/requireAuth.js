function requireAuthApi(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.status(401).json({ ok: false, error: 'Not authenticated.' });
}

function requireAuthPage(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.redirect('/admin/login');
}

module.exports = { requireAuthApi, requireAuthPage };
