// Manual/local use: npm run seed
// On a hosted deploy (Render, etc.) this happens automatically at server
// boot — see the ensureAdmin() call in server.js. This script is kept for
// local development and for forcing a check outside of a boot cycle.
require('dotenv').config();
const { ensureAdmin } = require('../utils/ensureAdmin');

ensureAdmin().then(result => {
  if (!result.ok) {
    console.error('Seeding failed:', result.reason);
    process.exit(1);
  }
  console.log('You can now log in at /admin/login with ADMIN_EMAIL / ADMIN_PASSWORD from .env.');
  process.exit(0);
}).catch(err => {
  console.error('Seeding failed:', err);
  process.exit(1);
});
